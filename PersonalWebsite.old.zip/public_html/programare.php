<html>
<head>
<title>Programari </title>
<meta name="robots" content="noindex,nofollow"/>

</head>

<body>
<p> Pentru a iti face programare cu <b> 2 zile </b> inainte
 urmeaza pasii:
 <BR>
<ol>
  <li>Deschide un nou tab in browser </li>
  <li>Intra pe <a href="http://programari.bigfitness.ro" target="_blank">programari.bigfitness.ro</a></li>
  <li>Logheaza-te cu email-ul tau</li>
  <li>Revino pe aceasta pagina, fara sa inchizi pagina bigfitness</li>
  <li>Alege una din urmatoarele optiuni</li>
</ol>
<b>Programarile trebuie facute cu exact 2 zile inainte de data clasei de TRX</b>  
	
</p>
<?php
$dateTime = new DateTime('NOW');
$dateTime->modify('+2 day');
?>
<form action="trimite.php" method="post">
<input type="radio" name="clasa" value="15.0">Marti - TRX (ora 9)
<br>
<input type="radio" name="clasa" value="210.0">Marti - TRX RIP (ora 18)
<br>
<input type="radio" name="clasa" value="185.0">Miercuri - TRX �ncep&#259;tori (ora 21)
<br>
<input type="radio" name="clasa" value="209.0">Miercuri - TRX Ball (ora 20)
<br>
<input type="radio" name="clasa" value="152.0">Joi - TRX (ora 20)
<br>
<input type="radio" name="clasa" value="126.0">Vineri - TRX RIP (ora 9)
<br>
<input type="radio" name="clasa" value="205.0">Vineri - TRX (ora 20)
<br>
<input type="radio" name="clasa" value="16.0">Sambata - TRX RIP (ora 9)
<br>
<input type="radio" name="clasa" value="25.0">Sambata - TRX (ora 10)
<br>
<input type="hidden" name="data" value="<?php echo $dateTime->format('d-m-Y');?>"
>
<br>
<input type="submit" value="Mai departe">
</form> 

</body>
</html>