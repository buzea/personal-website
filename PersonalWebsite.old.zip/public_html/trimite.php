<html>
<body>
<?php
 $data = $_POST["data"];
 //echo $data;
 $clasa = $_POST["clasa"];
 //echo $clasa;

 header("Location: http://188.26.115.155/site/start.php?sectiune=programari2&ID_CL=$clasa&wData=$data");

?>
</body>
</html>